from cipher import caesar_encrypt, caesar_decrypt
from utils import get_shift

def main():
    print("=" * 40)
    print("      CAESAR CIPHER TOOL")
    print("=" * 40)
    print("1. Encrypt Message")
    print("2. Decrypt Message")
    print("3. Exit")

    while True:
        choice = input("\nChoose option (1/2/3): ")

        if choice == "1":
            message = input("Enter message to encrypt: ")
            shift = get_shift()
            encrypted = caesar_encrypt(message, shift)
            print("\nEncrypted Message:", encrypted)

        elif choice == "2":
            message = input("Enter message to decrypt: ")
            shift = get_shift()
            decrypted = caesar_decrypt(message, shift)
            print("\nDecrypted Message:", decrypted)

        elif choice == "3":
            print("\nExiting program. Goodbye!")
            break

        else:
            print("Invalid choice. Try again.")


if __name__ == "__main__":
    main()
