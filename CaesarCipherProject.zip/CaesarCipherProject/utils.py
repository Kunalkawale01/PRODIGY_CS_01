def get_shift():
    while True:
        try:
            shift = int(input("Enter shift value (0–25): "))
            if 0 <= shift <= 25:
                return shift
            else:
                print("Shift must be between 0 and 25.")
        except ValueError:
            print("Please enter a valid number.")
