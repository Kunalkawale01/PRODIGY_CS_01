# Caesar Cipher Project (Python)

This project implements Caesar Cipher encryption and decryption.

## How to Run
python main.py
